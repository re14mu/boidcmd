const {version} = require('./package.json')
console.log(`v${version}`)